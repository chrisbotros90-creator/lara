//
//  ProcessListView.swift
//  lara
//
//  Created by ruter on 31.05.26.
//

import SwiftUI

struct ProcessInfo: Identifiable, Hashable {
    let id = UUID()
    let pid: Int32
    let uid: UInt32
    let gid: UInt32
    let name: String
    let kaddr: UInt64
}

struct ProcessListView: View {
    @ObservedObject private var mgr = laramgr.shared
    @State private var processes: [ProcessInfo] = []
    @State private var searchText: String = ""
    @State private var isLoading: Bool = false
    @State private var selectedProcess: ProcessInfo?
    @State private var showProcessDetail: Bool = false
    @State private var sortOrder: SortOrder = .name

    enum SortOrder: String, CaseIterable {
        case name = "Name"
        case pid  = "PID"
        case uid  = "UID"
    }

    private var filteredProcesses: [ProcessInfo] {
        let base = searchText.isEmpty
            ? processes
            : processes.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        switch sortOrder {
        case .name: return base.sorted { $0.name.lowercased() < $1.name.lowercased() }
        case .pid:  return base.sorted { $0.pid < $1.pid }
        case .uid:  return base.sorted { $0.uid < $1.uid }
        }
    }

    var body: some View {
        List {
            if !mgr.dsready {
                Section {
                    Text("Kernel R/W is not ready. Run the exploit first.")
                        .foregroundColor(.secondary)
                }
            }

            Section(header: HeaderLabel(text: "Options", icon: "arrow.up.arrow.down")) {
                Picker("Sort by", selection: $sortOrder) {
                    ForEach(SortOrder.allCases, id: \.self) { order in
                        Text(order.rawValue).tag(order)
                    }
                }
                .pickerStyle(.segmented)

                Button {
                    loadProcesses()
                } label: {
                    if isLoading {
                        HStack {
                            Text("Refreshing...")
                            Spacer()
                            ProgressView()
                        }
                    } else {
                        HStack {
                            Text("Refresh")
                            Spacer()
                            Text("\(processes.count) processes")
                                .foregroundColor(.secondary)
                                .font(.footnote)
                        }
                    }
                }
                .disabled(isLoading || !mgr.dsready)
            }

            Section(header: HeaderLabel(text: "Processes", icon: "cpu")) {
                if processes.isEmpty && !isLoading {
                    Text(mgr.dsready ? "Tap Refresh to load processes." : "Run exploit first.")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(filteredProcesses) { proc in
                        Button {
                            selectedProcess = proc
                            showProcessDetail = true
                        } label: {
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(proc.name)
                                        .foregroundColor(.primary)
                                        .fontWeight(.medium)
                                    Text("PID \(proc.pid)  UID \(proc.uid)")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .monospaced()
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .imageScale(.small)
                                    .foregroundStyle(.tertiary)
                            }
                        }
                    }
                }
            }
        }
        .searchable(text: $searchText, prompt: "Search processes")
        .navigationTitle("Process List")
        .sheet(isPresented: $showProcessDetail) {
            if let proc = selectedProcess {
                ProcessDetailSheet(proc: proc)
            }
        }
        .onAppear {
            if mgr.dsready && processes.isEmpty {
                loadProcesses()
            }
        }
    }

    private func loadProcesses() {
        guard mgr.dsready else { return }
        isLoading = true
        DispatchQueue.global(qos: .userInitiated).async {
            var count: Int32 = 0
            guard let list = proclist(nil, &count), count > 0 else {
                DispatchQueue.main.async { isLoading = false }
                return
            }
            var result: [ProcessInfo] = []
            for i in 0..<Int(count) {
                let entry = list[i]
                let name = withUnsafeBytes(of: entry.name) { raw -> String in
                    let ptr = raw.baseAddress!.assumingMemoryBound(to: CChar.self)
                    return String(cString: ptr)
                }
                result.append(ProcessInfo(
                    pid: Int32(entry.pid),
                    uid: entry.uid,
                    gid: entry.gid,
                    name: name,
                    kaddr: entry.kaddr
                ))
            }
            free_proclist(list)
            DispatchQueue.main.async {
                processes = result
                isLoading = false
            }
        }
    }
}

struct ProcessDetailSheet: View {
    let proc: ProcessInfo
    @Environment(\.dismiss) private var dismiss
    @State private var statusMessage: String?

    var body: some View {
        NavigationStack {
            List {
                Section(header: HeaderLabel(text: "Info", icon: "info.circle")) {
                    infoRow("Name",   value: proc.name)
                    infoRow("PID",    value: "\(proc.pid)")
                    infoRow("UID",    value: "\(proc.uid)")
                    infoRow("GID",    value: "\(proc.gid)")
                    infoRow("kaddr",  value: String(format: "0x%llx", proc.kaddr))
                }

                Section(header: HeaderLabel(text: "Actions", icon: "wrench.and.screwdriver")) {
                    Button {
                        UIPasteboard.general.string = proc.name
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        statusMessage = "Process name copied."
                    } label: {
                        Label("Copy Name", systemImage: "doc.on.doc")
                    }

                    Button {
                        UIPasteboard.general.string = "\(proc.pid)"
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        statusMessage = "PID copied."
                    } label: {
                        Label("Copy PID", systemImage: "number.circle")
                    }

                    Button(role: .destructive) {
                        Alertinator.shared.alert(
                            title: "Crash \(proc.name)?",
                            body: "This will crash the process with PID \(proc.pid). SpringBoard will respring if it is the target.",
                            actionLabel: "Crash"
                        ) {
                            proc.name.withCString { cstr in _ = crashproc(cstr) }
                            statusMessage = "Crash signal sent to \(proc.name)."
                        }
                    } label: {
                        Label("Crash Process", systemImage: "exclamationmark.triangle")
                    }
                }
            }
            .navigationTitle(proc.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .alert("Status", isPresented: .constant(statusMessage != nil)) {
                Button("OK") { statusMessage = nil }
            } message: {
                Text(statusMessage ?? "")
            }
        }
    }

    @ViewBuilder
    private func infoRow(_ label: String, value: String) -> some View {
        LabeledContent(label) {
            Text(value)
                .font(.system(.body, design: .monospaced))
                .foregroundColor(.secondary)
                .textSelection(.enabled)
        }
    }
}
