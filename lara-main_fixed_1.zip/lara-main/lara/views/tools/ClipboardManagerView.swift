import Combine
//
//  ClipboardManagerView.swift
//  lara
//
//  Created by ruter on 31.05.26.
//

import SwiftUI
import UniformTypeIdentifiers

// MARK: - Model

struct ClipboardEntry: Identifiable, Codable {
    var id: UUID = UUID()
    var content: String
    var date: Date
    var label: String = ""

    var preview: String {
        let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? "(empty)" : trimmed
    }
}

// MARK: - Manager

final class ClipboardManager: ObservableObject {
    static let shared = ClipboardManager()
    private let storageKey = "lara.clipboard.history"
    private let maxEntries = 50

    @Published var entries: [ClipboardEntry] = []

    private init() { load() }

    func snapshot() {
        let text = UIPasteboard.general.string ?? ""
        guard !text.isEmpty else { return }
        guard entries.first?.content != text else { return }
        let entry = ClipboardEntry(content: text, date: Date())
        entries.insert(entry, at: 0)
        if entries.count > maxEntries { entries = Array(entries.prefix(maxEntries)) }
        save()
    }

    func delete(at offsets: IndexSet) {
        entries.remove(atOffsets: offsets)
        save()
    }

    func clear() {
        entries.removeAll()
        save()
    }

    func pin(_ entry: ClipboardEntry) {
        guard let idx = entries.firstIndex(where: { $0.id == entry.id }) else { return }
        var updated = entries[idx]
        updated.label = updated.label.isEmpty ? "Pinned" : ""
        entries[idx] = updated
        save()
    }

    func rename(_ entry: ClipboardEntry, to label: String) {
        guard let idx = entries.firstIndex(where: { $0.id == entry.id }) else { return }
        entries[idx].label = label
        save()
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(entries) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([ClipboardEntry].self, from: data)
        else { return }
        entries = decoded
    }
}

// MARK: - View

struct ClipboardManagerView: View {
    @StateObject private var manager = ClipboardManager.shared
    @State private var searchText: String = ""
    @State private var showNewEntry: Bool = false
    @State private var newEntryText: String = ""
    @State private var renamingEntry: ClipboardEntry?
    @State private var renameText: String = ""

    private var filtered: [ClipboardEntry] {
        guard !searchText.isEmpty else { return manager.entries }
        return manager.entries.filter {
            $0.content.localizedCaseInsensitiveContains(searchText) ||
            $0.label.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        List {
            Section(header: HeaderLabel(text: "Actions", icon: "tray")) {
                Button {
                    manager.snapshot()
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                } label: {
                    Label("Capture Current Clipboard", systemImage: "doc.on.clipboard")
                }

                Button {
                    showNewEntry = true
                } label: {
                    Label("Add Manual Entry", systemImage: "plus.circle")
                }

                if !manager.entries.isEmpty {
                    Button(role: .destructive) {
                        Alertinator.shared.alert(
                            title: "Clear History?",
                            body: "This will delete all \(manager.entries.count) saved clipboard entries.",
                            actionLabel: "Clear All"
                        ) {
                            manager.clear()
                        }
                    } label: {
                        Label("Clear All Entries", systemImage: "trash")
                    }
                }
            }

            Section(
                header: HeaderLabel(text: "History (\(manager.entries.count))", icon: "clock"),
                footer: Text("Tap an entry to copy it. Swipe to delete. Long-press for more options.")
            ) {
                if filtered.isEmpty {
                    Text(manager.entries.isEmpty
                         ? "No entries yet. Tap \"Capture Current Clipboard\" to save what's on your clipboard."
                         : "No results for \"\(searchText)\".")
                        .foregroundColor(.secondary)
                        .font(.subheadline)
                } else {
                    ForEach(filtered) { entry in
                        ClipboardEntryRow(entry: entry)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                UIPasteboard.general.string = entry.content
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            }
                            .contextMenu {
                                Button {
                                    UIPasteboard.general.string = entry.content
                                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                } label: {
                                    Label("Copy", systemImage: "doc.on.doc")
                                }

                                Button {
                                    renamingEntry = entry
                                    renameText = entry.label
                                } label: {
                                    Label("Rename", systemImage: "pencil")
                                }

                                Button {
                                    manager.pin(entry)
                                } label: {
                                    let isPinned = !entry.label.isEmpty
                                    Label(isPinned ? "Unpin" : "Pin", systemImage: isPinned ? "pin.slash" : "pin")
                                }

                                Divider()

                                Button(role: .destructive) {
                                    if let idx = manager.entries.firstIndex(where: { $0.id == entry.id }) {
                                        manager.delete(at: IndexSet(integer: idx))
                                    }
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                    }
                    .onDelete { manager.delete(at: $0) }
                }
            }
        }
        .searchable(text: $searchText, prompt: "Search history")
        .navigationTitle("Clipboard Manager")
        // Manual entry sheet
        .sheet(isPresented: $showNewEntry) {
            NavigationStack {
                Form {
                    Section("Content") {
                        TextEditor(text: $newEntryText)
                            .frame(minHeight: 120)
                    }
                }
                .navigationTitle("New Entry")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") {
                            newEntryText = ""
                            showNewEntry = false
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") {
                            let trimmed = newEntryText.trimmingCharacters(in: .whitespacesAndNewlines)
                            if !trimmed.isEmpty {
                                let entry = ClipboardEntry(content: trimmed, date: Date(), label: "Manual")
                                manager.entries.insert(entry, at: 0)
                            }
                            newEntryText = ""
                            showNewEntry = false
                        }
                        .disabled(newEntryText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
            }
        }
        // Rename alert
        .alert("Rename Entry", isPresented: .constant(renamingEntry != nil)) {
            TextField("Label (optional)", text: $renameText)
            Button("Save") {
                if let entry = renamingEntry {
                    manager.rename(entry, to: renameText)
                }
                renamingEntry = nil
                renameText = ""
            }
            Button("Cancel", role: .cancel) {
                renamingEntry = nil
                renameText = ""
            }
        } message: {
            Text("Give this entry a custom label.")
        }
    }
}

// MARK: - Row

private struct ClipboardEntryRow: View {
    let entry: ClipboardEntry

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .short
        f.timeStyle = .short
        return f
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(alignment: .top) {
                if !entry.label.isEmpty {
                    Text(entry.label)
                        .font(.caption.weight(.semibold))
                        .foregroundColor(.accentColor)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.accentColor.opacity(0.12), in: Capsule())
                }
                Spacer()
                Text(Self.dateFormatter.string(from: entry.date))
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            Text(entry.preview)
                .lineLimit(3)
                .font(.system(.subheadline, design: .monospaced))
                .foregroundColor(.primary)
        }
        .padding(.vertical, 2)
    }
}
