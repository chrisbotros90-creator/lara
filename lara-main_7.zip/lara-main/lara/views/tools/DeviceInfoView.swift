//
//  DeviceInfoView.swift
//  lara
//
//  Created by ruter on 31.05.26.
//

import SwiftUI
import UIKit

struct DeviceInfoView: View {
    @State private var info: DeviceSnapshot = DeviceSnapshot()
    @State private var refreshID: Int = 0

    var body: some View {
        List {
            // Battery
            Section(header: HeaderLabel(text: "Battery", icon: "battery.100")) {
                infoRow("Level", value: info.batteryLevelString)
                infoRow("State", value: info.batteryStateString)
                infoRow("Low Power Mode", value: info.isLowPowerMode ? "Enabled" : "Disabled",
                        valueColor: info.isLowPowerMode ? .orange : .secondary)
            }

            // Device
            Section(header: HeaderLabel(text: "Device", icon: "iphone")) {
                infoRow("Model", value: info.model)
                infoRow("System Version", value: info.systemVersion)
                infoRow("Device Name", value: info.deviceName)
                infoRow("Identifier (UDID)", value: info.udid)
                infoRow("Boot UUID", value: info.bootSessionUUID)
            }

            // Screen
            Section(header: HeaderLabel(text: "Screen", icon: "rectangle.on.rectangle")) {
                infoRow("Resolution", value: info.screenResolution)
                infoRow("Scale", value: info.screenScale)
                infoRow("Brightness", value: info.brightness)
            }

            // Storage
            Section(header: HeaderLabel(text: "Storage", icon: "internaldrive")) {
                infoRow("Total", value: info.totalDisk)
                infoRow("Free",  value: info.freeDisk)
                infoRow("Used",  value: info.usedDisk)
                StorageBar(used: info.usedDiskFraction)
                    .frame(height: 8)
                    .padding(.vertical, 4)
                    .listRowSeparator(.hidden)
            }

            // Memory (RAM)
            Section(header: HeaderLabel(text: "Memory", icon: "memorychip")) {
                infoRow("Physical RAM", value: info.physicalMemory)
                infoRow("App Used",     value: info.appMemoryUsed)
            }

            // Network
            Section(header: HeaderLabel(text: "Network", icon: "wifi")) {
                infoRow("WiFi Address", value: info.wifiAddress)
            }

            Section {
                Button {
                    info = DeviceSnapshot()
                    refreshID += 1
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                } label: {
                    HStack {
                        Spacer()
                        Label("Refresh", systemImage: "arrow.clockwise")
                        Spacer()
                    }
                }
            }
        }
        .navigationTitle("Device Info")
        .id(refreshID)
    }

    @ViewBuilder
    private func infoRow(_ label: String, value: String, valueColor: Color = .secondary) -> some View {
        LabeledContent(label) {
            Text(value)
                .font(.system(.body, design: .monospaced))
                .foregroundColor(valueColor)
                .textSelection(.enabled)
                .multilineTextAlignment(.trailing)
        }
    }
}

// MARK: - Storage bar

private struct StorageBar: View {
    let used: Double
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 4)
                    .fill(Color(.systemFill))
                RoundedRectangle(cornerRadius: 4)
                    .fill(used > 0.9 ? Color.red : used > 0.7 ? Color.orange : Color.accentColor)
                    .frame(width: geo.size.width * CGFloat(min(used, 1.0)))
            }
        }
    }
}

// MARK: - DeviceSnapshot

struct DeviceSnapshot {
    // Battery
    let batteryLevelString: String
    let batteryStateString: String
    let isLowPowerMode: Bool

    // Device
    let model: String
    let systemVersion: String
    let deviceName: String
    let udid: String
    let bootSessionUUID: String

    // Screen
    let screenResolution: String
    let screenScale: String
    let brightness: String

    // Storage
    let totalDisk: String
    let freeDisk: String
    let usedDisk: String
    let usedDiskFraction: Double

    // Memory
    let physicalMemory: String
    let appMemoryUsed: String

    // Network
    let wifiAddress: String

    init() {
        let device = UIDevice.current
        device.isBatteryMonitoringEnabled = true

        // Battery
        let level = device.batteryLevel
        batteryLevelString = level < 0 ? "Unknown" : String(format: "%.0f%%", level * 100)
        switch device.batteryState {
        case .charging:    batteryStateString = "Charging"
        case .full:        batteryStateString = "Full"
        case .unplugged:   batteryStateString = "Unplugged"
        default:           batteryStateString = "Unknown"
        }
        isLowPowerMode = ProcessInfo.processInfo.isLowPowerModeEnabled

        // Device
        model         = device.model
        systemVersion = "\(device.systemName) \(device.systemVersion)"
        deviceName    = device.name

        // UDID from identifierForVendor (closest available without entitlements)
        udid          = device.identifierForVendor?.uuidString ?? "Unavailable"

        // Boot session UUID
        bootSessionUUID = ProcessInfo.processInfo.globallyUniqueString

        // Screen
        let bounds = UIScreen.main.bounds
        let scale  = UIScreen.main.scale
        screenResolution = "\(Int(bounds.width * scale)) × \(Int(bounds.height * scale)) px"
        screenScale      = "\(scale)x"
        brightness       = String(format: "%.0f%%", UIScreen.main.brightness * 100)

        // Storage
        let fm = FileManager.default
        if let attrs = try? fm.attributesOfFileSystem(forPath: NSHomeDirectory()) {
            let total = (attrs[.systemSize] as? Int64) ?? 0
            let free  = (attrs[.systemFreeSize] as? Int64) ?? 0
            let used  = total - free
            totalDisk        = DeviceSnapshot.formatBytes(total)
            freeDisk         = DeviceSnapshot.formatBytes(free)
            usedDisk         = DeviceSnapshot.formatBytes(used)
            usedDiskFraction = total > 0 ? Double(used) / Double(total) : 0
        } else {
            totalDisk = "N/A"; freeDisk = "N/A"; usedDisk = "N/A"; usedDiskFraction = 0
        }

        // Memory
        let physMem = ProcessInfo.processInfo.physicalMemory
        physicalMemory = DeviceSnapshot.formatBytes(Int64(physMem))

        var taskInfo = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &taskInfo) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count)
            }
        }
        if result == KERN_SUCCESS {
            appMemoryUsed = DeviceSnapshot.formatBytes(Int64(taskInfo.phys_footprint))
        } else {
            appMemoryUsed = "N/A"
        }

        // Network — WiFi address via getifaddrs
        wifiAddress = DeviceSnapshot.wifiIPAddress() ?? "Not connected"
    }

    private static func formatBytes(_ bytes: Int64) -> String {
        let gb = Double(bytes) / 1_073_741_824
        if gb >= 1 { return String(format: "%.2f GB", gb) }
        let mb = Double(bytes) / 1_048_576
        if mb >= 1 { return String(format: "%.1f MB", mb) }
        return "\(bytes) B"
    }

    private static func wifiIPAddress() -> String? {
        var address: String?
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let firstAddr = ifaddr else { return nil }
        defer { freeifaddrs(ifaddr) }
        var ptr: UnsafeMutablePointer<ifaddrs>? = firstAddr
        while let current = ptr {
            let interface = current.pointee
            let af = interface.ifa_addr.pointee.sa_family
            if af == UInt8(AF_INET) {
                let name = String(cString: interface.ifa_name)
                if name == "en0" {
                    var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    getnameinfo(interface.ifa_addr, socklen_t(interface.ifa_addr.pointee.sa_len),
                                &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST)
                    address = String(cString: hostname)
                }
            }
            ptr = interface.ifa_next
        }
        return address
    }
}
